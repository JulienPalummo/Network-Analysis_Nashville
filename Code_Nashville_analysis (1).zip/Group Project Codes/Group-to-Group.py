# -*- coding: utf-8 -*-
"""
Created on Fri Apr 19 15:27:46 2024

@author: Belma
"""
#%%

##################
###PLOT NETWORK###
##################

#Import Libraries
import pandas as pd
import networkx as nx
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

#Import Group Edge Dataset
df = pd.read_csv("/Users/samiabelmadani/Downloads/group-edges.csv")


g = nx.from_pandas_edgelist(df, 
                            source='group1', 
                            target='group2', 
                            edge_attr='weight')

print('The member graph has {} nodes and {} edges.'.format(len(g.nodes),
                                                          len(g.edges)))
#The member graph has 456 nodes and 6692 edges


g = nx.from_pandas_edgelist(df, 
                            source='group1', 
                            target='group2', 
                            edge_attr='weight')

# Plot the network
plt.figure(figsize=(20, 10))
nx.draw(g, with_labels=True, node_size=50)
plt.title('Network of Group Connections')
plt.show()
#%%

#%%% CENTRALITY MEASURE ANALYSIS
#Import group metadata
groups = pd.read_csv("/Users/samiabelmadani/Downloads/meta-groups.csv", index_col='group_id')
print('There are {} groups with metadata.'.format(groups.shape[0]))
#There are 603 groups 

# Print unique category values
unique_categories = groups['category_name'].unique()
print("Unique category values:", unique_categories)

#Let's filter out the groups that are not present in the graph
groups = groups.loc[[x for x in g.nodes]]
print('After filtering, there are {} groups.'.format(groups.shape[0]))
groups.head()
#There are 456 groups

#Let's create some measures
groups['degree'] = pd.Series(dict(nx.degree(g)))
groups['betweeness'] = pd.Series(nx.betweenness_centrality(g))
groups['closeness'] = pd.Series(nx.closeness_centrality(g))
groups['eigenvector'] = pd.Series(nx.eigenvector_centrality(g))

#Average Degree Coefficient 
fig, ax = plt.subplots(1,1, figsize=(5,10), dpi=100)

sns.barplot(data=groups, x='degree', y='category_name', 
            order=groups.groupby('category_name').degree.mean().sort_values().index)
ax.set_title('Average degree coefficient by Category')

plt.show()

#Average betweeness Coefficient 
fig, ax = plt.subplots(1,1, figsize=(5,10), dpi=100)

sns.barplot(data=groups, x='betweeness', y='category_name', 
            order=groups.groupby('category_name').degree.mean().sort_values().index)
ax.set_title('Average betweeness coefficient by Category')

plt.show()

#Average closeness Coefficient 
fig, ax = plt.subplots(1,1, figsize=(5,10), dpi=100)

sns.barplot(data=groups, x='closeness', y='category_name', 
            order=groups.groupby('category_name').degree.mean().sort_values().index)
ax.set_title('Average closeness coefficient by Category')

plt.show()

#Average eigenvector Coefficient 
fig, ax = plt.subplots(1,1, figsize=(5,10), dpi=100)

sns.barplot(data=groups, x='eigenvector', y='category_name', 
            order=groups.groupby('category_name').degree.mean().sort_values().index)
ax.set_title('Average eigenvector coefficient by Category')

plt.show()


# Plot the Number of Members  vs. centrality
fig, ax = plt.subplots(1,1, figsize=(10,5))

sns.regplot(data=groups, x='num_members', y='betweeness')
ax.set_title('Relationship between centrality and number of members')
ax.set_xlim([0,7000])

plt.show()

#%%%

#%%%
#TOP 10 MOST CENTRAL GROUPS

import matplotlib.pyplot as plt

# Sort groups by centrality in descending order and select the top 10
top_groups = groups.sort_values(by='betweeness', ascending=False).head(10)

# Create a bar plot
plt.figure(figsize=(10, 6))
plt.barh(top_groups['group_name'], top_groups['betweeness'], color='skyblue')
plt.xlabel('Centrality')
plt.ylabel('Group Name')
plt.title('Top 10 Most Central Groups')
plt.gca().invert_yaxis()  # Invert y-axis to display the highest centrality at the top
plt.show()

#%%%

#FOCUS ANALYSIS ON CAREER & BUSINESS GROUPS 
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

g0 = nx.from_pandas_edgelist(df, 
                            source='group1', 
                            target='group2', 
                            edge_attr='weight')

print('The entire MeetUp group graph has {} nodes and {} edges.'.format(
    len(g0.nodes),
    len(g0.edges)))

career = groups.loc[groups.category_name == 'Career & Business']
print('There are {} Career groups with metadata.'.format(career.shape[0]))

# Let's trim the graph down to the largest connected Career & Business network
gt = g0.subgraph(career.index)
g = [gt.subgraph(c) for c in nx.connected_components(gt)][0]
career = career.loc[(n for n in g.nodes)]
print('After trimming, there are {} groups with metadata.\nThese include...'.format(career.shape[0]))
print(career.sample(5).group_name.to_string())

plt.figure(dpi=150)


# Calculate node centrality measures
betweenness_centrality = nx.betweenness_centrality(g)
degree_centrality = nx.degree_centrality(g)
closeness_centrality = nx.closeness_centrality(g)
eigenvector_centrality = nx.eigenvector_centrality(g)

# Identify the top 5 most influential nodes for each centrality measure
top_betweenness_nodes = sorted(betweenness_centrality, key=betweenness_centrality.get, reverse=True)[:5]
top_degree_nodes = sorted(degree_centrality, key=degree_centrality.get, reverse=True)[:5]
top_closeness_nodes = sorted(closeness_centrality, key=closeness_centrality.get, reverse=True)[:5]
top_eigenvector_nodes = sorted(eigenvector_centrality, key=eigenvector_centrality.get, reverse=True)[:5]

# Draw the network with smaller nodes for all other nodes
pos = nx.spring_layout(g, k=2)
nx.draw_networkx_nodes(g, pos, nodelist=[node for node in g.nodes() if node not in top_betweenness_nodes 
                                         and node not in top_degree_nodes 
                                         and node not in top_closeness_nodes 
                                         and node not in top_eigenvector_nodes], 
                       node_size=10, node_color='black')

# Draw the network with larger node size for the top 5 nodes for each centrality measure
nx.draw_networkx_nodes(g, pos, nodelist=top_betweenness_nodes, node_size=100, node_color='red', label='Top Betweenness')
nx.draw_networkx_nodes(g, pos, nodelist=top_degree_nodes, node_size=100, node_color='blue', label='Top Degree')
nx.draw_networkx_nodes(g, pos, nodelist=top_closeness_nodes, node_size=100, node_color='green', label='Top Closeness')
nx.draw_networkx_nodes(g, pos, nodelist=top_eigenvector_nodes, node_size=100, node_color='orange', label='Top Eigenvector')
nx.draw_networkx_edges(g, pos, width=0.05)

# Add legend in the top right corner
plt.legend(loc='upper right', fontsize='xx-small', markerscale=0.6)

ax = plt.gca()
ax.set_aspect(1)
ax.axis('off')
ax.set_title('Graph Network of Nashville Career & Business MeetUps')
plt.show()

#%%%

#%%%%
#INVESTIGATE COMMUNITIES 

# !pip install python-louvain

def community_layout(g, partition):
    """
    Compute the layout for a modular graph.


    Arguments:
    ----------
    g -- networkx.Graph or networkx.DiGraph instance
        graph to plot

    partition -- dict mapping int node -> int community
        graph partitions


    Returns:
    --------
    pos -- dict mapping int node -> (float x, float y)
        node positions

    """

    pos_communities = _position_communities(g, partition, scale=3.)

    pos_nodes = _position_nodes(g, partition, scale=1.)

    # combine positions
    pos = dict()
    for node in g.nodes():
        pos[node] = pos_communities[node] + pos_nodes[node]

    return pos

def _position_communities(g, partition, **kwargs):

    # create a weighted graph, in which each node corresponds to a community,
    # and each edge weight to the number of edges between communities
    between_community_edges = _find_between_community_edges(g, partition)

    communities = set(partition.values())
    hypergraph = nx.DiGraph()
    hypergraph.add_nodes_from(communities)
    for (ci, cj), edges in between_community_edges.items():
        hypergraph.add_edge(ci, cj, weight=len(edges))

    # find layout for communities
    pos_communities = nx.spring_layout(hypergraph, **kwargs)

    # set node positions to position of community
    pos = dict()
    for node, community in partition.items():
        pos[node] = pos_communities[community]

    return pos

def _find_between_community_edges(g, partition):

    edges = dict()

    for (ni, nj) in g.edges():
        ci = partition[ni]
        cj = partition[nj]

        if ci != cj:
            try:
                edges[(ci, cj)] += [(ni, nj)]
            except KeyError:
                edges[(ci, cj)] = [(ni, nj)]

    return edges

def _position_nodes(g, partition, **kwargs):
    """
    Positions nodes within communities.
    """

    communities = dict()
    for node, community in partition.items():
        try:
            communities[community] += [node]
        except KeyError:
            communities[community] = [node]

    pos = dict()
    for ci, nodes in communities.items():
        subgraph = g.subgraph(nodes)
        pos_subgraph = nx.spring_layout(subgraph, **kwargs)
        pos.update(pos_subgraph)

    return pos

def community_layout(g, partition):
    """
    Compute the layout for a modular graph.


    Arguments:
    ----------
    g -- networkx.Graph or networkx.DiGraph instance
        graph to plot

    partition -- dict mapping int node -> int community
        graph partitions


    Returns:
    --------
    pos -- dict mapping int node -> (float x, float y)
        node positions

    """

    pos_communities = _position_communities(g, partition, scale=3.)

    pos_nodes = _position_nodes(g, partition, scale=1.)

    # combine positions
    pos = dict()
    for node in g.nodes():
        pos[node] = pos_communities[node] + pos_nodes[node]

    return pos

def _position_communities(g, partition, **kwargs):

    # create a weighted graph, in which each node corresponds to a community,
    # and each edge weight to the number of edges between communities
    between_community_edges = _find_between_community_edges(g, partition)

    communities = set(partition.values())
    hypergraph = nx.DiGraph()
    hypergraph.add_nodes_from(communities)
    for (ci, cj), edges in between_community_edges.items():
        hypergraph.add_edge(ci, cj, weight=len(edges))

    # find layout for communities
    pos_communities = nx.spring_layout(hypergraph, **kwargs)

    # set node positions to position of community
    pos = dict()
    for node, community in partition.items():
        pos[node] = pos_communities[community]

    return pos

def _find_between_community_edges(g, partition):

    edges = dict()

    for (ni, nj) in g.edges():
        ci = partition[ni]
        cj = partition[nj]

        if ci != cj:
            try:
                edges[(ci, cj)] += [(ni, nj)]
            except KeyError:
                edges[(ci, cj)] = [(ni, nj)]

    return edges

def _position_nodes(g, partition, **kwargs):
    """
    Positions nodes within communities.
    """

    communities = dict()
    for node, community in partition.items():
        try:
            communities[community] += [node]
        except KeyError:
            communities[community] = [node]

    pos = dict()
    for ci, nodes in communities.items():
        subgraph = g.subgraph(nodes)
        pos_subgraph = nx.spring_layout(subgraph, **kwargs)
        pos.update(pos_subgraph)

    return pos 

import community

partition = community.community_louvain.best_partition(g)
career['community'] = pd.Series(partition)

plt.figure(dpi=150)

pos = community_layout(g, partition)

cdict = {ii: sns.color_palette()[ii] for ii in set(partition.values())}
nx.draw_networkx(g, pos, node_size=60,
                 node_color=[cdict[ii] for ii in partition.values()], 
                 with_labels=False, width=0.15,
                 cmap='rainbow')
plt.axis('off')
plt.show()

for ii in career.community.unique():
    print('Most central groups in Community {}...'.format(ii))
    tdf = career.sort_values(by='betweeness', ascending=False).loc[career.community == ii]
    for ix, gp in tdf.head(4).iterrows():
        print('\t{}'.format(gp.group_name, gp.num_members))

#%%%
#Topic Modelling on Communities 

community0 = career[career['community'] == 0]
community1 = career[career['community'] == 1]
community2 = career[career['community'] == 2]
community3 = career[career['community'] == 3]


#Import libraries
import pandas as pd
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.feature_extraction.text import CountVectorizer
import pandas as pd
import re
import spacy

####################
###Pre-processing###
####################

nlp = spacy.load('en_core_web_sm')


def clean_text(x):
    # Convert to lowercase
    x = x.lower()
    # Remove new line
    x = re.sub(r'\n', ' ', x)
    # Remove links
    x = re.sub(r"https?://[^\s]+", "", x)
    # Remove hashtags
    x = re.sub(r'\#[A-Za-z0-9\_]+', ' ', x)
    # Remove bullet points preceded by words
    x = re.sub(r'(\w)-', r'\1 ', x)
    # Remove numbers followed by periods
    x = re.sub(r'\b\d+\.\s+', '', x)
    # Remove commas
    x = re.sub(r',', '', x)
    # Remove stop words
    stop_words = ["》", "•", "/", "|", ".", "?", ";", ":", "!", 
                  "...", "e.g.", "#", "*", "+", "-", "\"", "1.", "1-", ">", "1)", "%", "$"]
    for word in stop_words:
        x = x.replace(word, '')
    # Remove numbers attached to words
    x = re.sub(r'\b\d+\b', '', x)
    # Lemmatization
    x = ' '.join([token.lemma_ for token in nlp(x)])
    # Remove multiple spaces
    x = re.sub(r' +', ' ', x)
    # Remove leading and trailing spaces
    x = x.strip()
    return x

# Example usage
community3['clean_group_name'] = career['group_name'].apply(clean_text)

#########
###LDA###
#########

# We indicate that we would like to exclude any English stopwords, words that show up in less than 2 documents
# and words that are common across 90% of the documents in the corpus since these words would not help with distinguishing the documents.
cv = CountVectorizer(max_df=0.9, min_df=2, stop_words="english")

dtm = cv.fit_transform(community3["clean_group_name"])

lda = LatentDirichletAllocation(n_components=3, random_state=42)

# We train the model.
lda.fit(dtm)

len(cv.get_feature_names())

len(lda.components_[0])

# Print the top 4 words in each topic
n = 4

for index, topic in enumerate(lda.components_):
    print(f'The top {n} words for topic #{index}')
    print([cv.get_feature_names()[i] for i in topic.argsort()[-n:]])

topic_results = lda.transform(dtm)

print(topic_results[0].round(2))

# Get the highest probability in the topic distribution and assign it as the topic of the document
community3["Topic"] = topic_results.argmax(axis=1)

community3.head()

###############
###Bar Plot####
###############

import matplotlib.pyplot as plt

# Define a function to visualize topics using bar plots
def visualize_topics(lda_model, cv_model, num_words=3):
    # Get the feature names (words) from the CountVectorizer
    feature_names = cv_model.get_feature_names()

    # Plot bar plots for each topic
    for topic_idx, topic in enumerate(lda_model.components_):
        # Sort words by their weights in the topic
        sorted_word_indices = topic.argsort()[:-num_words-1:-1]
        sorted_words = [feature_names[i] for i in sorted_word_indices]
        sorted_weights = [topic[i] for i in sorted_word_indices]

        # Plot bar plot
        plt.figure(figsize=(10, 5))
        plt.barh(sorted_words, sorted_weights, color='skyblue')
        plt.xlabel('Weight')
        plt.ylabel('Word')
        plt.title(f'Topic #{topic_idx}', fontsize=20)
        plt.gca().invert_yaxis()  # Invert y-axis to display top words at the top
        plt.show()

# Call the function to visualize topics
visualize_topics(lda, cv)

#COMMUNITY 0 
#The top 4 words for topic #0
##['marketing', 'business', 'meetup', 'nashville']
##[The top 4 words for topic #1
##[['business', 'entrepreneur', 'nashville', 'online']
##[The top 4 words for topic #2
##[['marketing', 'entrepreneur', 'seo', 'nashville']
##[[0.61 0.32 0.07]
#WE CAN UNDERSTAND THAT THE FIRST COMMUNITY HAS TO DO WITH MARKETING 

#COMMUNITY 1 
##The top 4 words for topic #0
##['nashville', 'franklin', 'professional', 'club']
##The top 4 words for topic #1
##['nashville', 'middle', 'tennessee', 'network']
##The top 4 words for topic #2
##['nashville', 'group', 'networking', 'business']
##[0.43 0.09 0.48]
#WE CAN INFER THAT THIS COMMUNITY IS RELATETED TO NETWORKING EVENTS

#COMMUNITY 2
##The top 4 words for topic #0
##['business', 'nashville', 'wine', 'woman']
##The top 4 words for topic #1
####The top 4 words for topic #2
##['nashville', 'woman', 'business', 'network']
##[0.78 0.11 0.11]
#WE CAN INFER THAT THIS COMMUNITY IS RELATED TO WOMAN RELATED EVENTS

#COMMUNITY 3
#The top 4 words for topic #0
#['meetup', 'estate', 'real', 'investor']
#The top 4 words for topic #1
#['real', 'estate', 'meetup', 'nashville']
#The top 4 words for topic #2
#['meetup', 'investor', 'real', 'estate']
#[0.72 0.22 0.06]
#WE CAN INFER THAT THIS HAS TO DO WITH REAL ESTATE EVENTS

# Specify the path where you want to save the dataset
save_path = "/Users/samiabelmadani/Downloads/career.csv"  # Choose the path where you want to save the dataset

# Save the dataset to the specified path
career.to_csv(save_path, index=False)
print("Dataset saved successfully.")